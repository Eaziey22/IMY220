
function checkDate(dateString){

    const date = new Date(dateString);

    const sep9th = new Date(2024, 9, 9);
    const sep21st = new Date(2024, 9, 21);

    return ( date.getDate() > sep9th.getDate() && date.getDate() <= sep21st.getDate());
}

function checkName(name){

    const regex = /[^A-Za-z0-9]/;

    if(regex.test(name)){
        return false;
    }
    else{
        return true;
    }

}

module.exports = {checkDate, checkName}