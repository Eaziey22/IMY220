const fs = require("fs");

async function fileRead(){

    try{
        const data =  fs.readFileSync("Events.json");

        return JSON.parse(data);
    }
    catch(err){
        console.error("An error has occurred: ", err);
        return [];
    }

}

async function fileWrite(dt){
    try{

        fs.writeFileSync("newEvents.json", dt);

        console.log("File written successfully");

    }
    catch(err){
        console.error("An error has occurred: ", err)
    }
}

module.exports = {fileRead, fileWrite}
