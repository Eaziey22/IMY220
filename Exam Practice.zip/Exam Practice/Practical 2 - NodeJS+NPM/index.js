const { fileRead, fileWrite } = require("./fileManager");
const { checkDate, checkName } = require("./dataValidation");


async function mainFunction(){

    const data = await fileRead();
    //console.log(data);

    const filteredData = data.filter((d) =>{

        if(checkDate(d.date)){
            return d;
        }
    });

    console.log(filteredData);
    
    const validNameData = filteredData.map((data, index) =>{
    
        if(checkName(data.title)){
            data.validName = true;
        }
        else{
            data.validName = false;
        }
    
        return data;
    })
    
    
    await fileWrite(JSON.stringify(validNameData));

}

mainFunction();

