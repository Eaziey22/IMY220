import React from 'react';
import { EditPost } from './editPost';

export class Post extends React.Component{
    constructor(props){
        super(props);
        this.state ={
            title: this.props.title,
            author: this.props.author,
            description: this.props.description,
            showForm: false
        };
    }

    toggleForm = () =>{
        this.setState({showForm: !this.state.showForm});
    };

    savePost = ({title, description}) => {
        this.setState({
            title: title,
            description: description,
            showForm: false
        });
    };

    render(){
        return(
            <div>
                <h2>{this.state.title}</h2>
                <p>{this.state.author}</p>
                <hr></hr>
                <p>{this.state.description}</p>
                <button onClick={this.toggleForm}>Edit Post</button>

                {this.state.showForm &&(
                    <div style={{marginTop: 20}}>
                        <EditPost title={this.state.title} description = {this.state.description} onSave={this.savePost}/>
                    </div>
                )}
            </div>

        );
    }

}