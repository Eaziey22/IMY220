import React from 'react';

export class EditPost extends React.Component{

    constructor(props) {
        super(props);
        this.state = {
          title: this.props.title,
          description: this.props.description,
        };
      }

    handleInputChange = (e) =>{
        const {name, value} = e.target;
        this.setState({[name]: value});
    };

    handleSubmit = (e) => {
        e.preventDefault();

        const {title,  description} = this.state;
        this.props.onSave({title, description});
    };

    render(){
        return(
            <form onSubmit={this.handleSubmit}>
                <div>
                    <label>Post Title</label><br/>
                    <input style={{marginTop: 10, marginBottom: 10}} type="text" name="title" defaultValue={this.state.title} onChange={this.handleInputChange}></input><br/>
                    <label >Post Description</label><br/>
                    <input style={{marginTop: 10}} type="text" name="description" defaultValue={this.state.description} onChange={this.handleInputChange} ></input><br/>
                    
                </div>
                <button style={{marginTop: 10}} type="submit">Save</button>
            </form>

        );

        
    }
};