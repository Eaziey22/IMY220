import React from 'react';
import { createBrowserRouter, RouterProvider } from 'react-router-dom';

import {Home} from './pages/Home';
import { Posts } from './pages/Posts';

const router = createBrowserRouter([{
    path: "/",
    element: <Home/>,
    errorElement: <div>404 Not Found</div>
},
{
    path:"/posts",
    element: <Posts/>,
    errorElement: <div>404 Not Found</div>
}
]);

class App extends React.Component{
    render(){
        return (
                <RouterProvider router={router}>
             
                </RouterProvider>

            
            

        );
    }
}

export default App;