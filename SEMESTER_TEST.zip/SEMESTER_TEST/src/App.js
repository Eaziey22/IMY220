import React from "react";

import { Line } from "./components/Line";

let array1 = [1,1,1];
var array2 = [2,2,2];

export class App extends React.Component{
    render(){
        return(
            <div>
                <Line point1= {array1} point2 ={array2}/>
            </div>
        )
    }
}