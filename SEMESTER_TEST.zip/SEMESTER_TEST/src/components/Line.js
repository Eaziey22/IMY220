import React from "react";
import propTypes from "prop-types";

export class Line extends React.Component{

    constructor(props){
        super(props);
        this.state = {
            point1 : [],
            point2 : []

        }
    }

    getEuclideanDistance = () =>{

        let a = this.state.point1;
        let b = this.state.point2;

        var subtractionArr = a.map((num , index)=>{
            let sub = num - b[index];

            return sub * sub;
            
        });

        var sum = subtractionArr.reduce((accum, currElement) => {
            return accum + currElement;
        });

        var sqrd = Math.sqrt(sum);

        return sqrd.toFixed(2);

    };

    getFirstPoints = () =>{
        var a = this.state.point1;
        

        var A = a.map((num, index) =>{

            if(index != a.length){
                return `${num};`;
            }
            else{
                return `${num}`;
            }
            
            
        });

        return A;
        
    }

    getSecondPoints = () =>{

        var b = this.state.point2;

        var B = b.map((num, index) =>{

            if(index != b.length){
                return `${num};`;
            }
            else{
                return `${num}`;
            }
            
        
        });

        
        return B;
    }


    render(){
        
        let {p1} = this.props.point1;
        let {p2} = this.props.point2;

        this.setState({point1: p1, point2: p2});


        return(
            
            <div>
                <p>Point 1: {this.getFirstPoints()}</p>
                <p>Point 2: {this.getSecondPoints()}</p>
                <p>Dimension:  {this.state.point1.length}</p>
                <p>Euclidean Distance: {this.getEuclideanDistance()} </p>
            </div>
        );
    }

    
}

Line.propTypes = {
        point1: propTypes.array.isRequired,
        point2: propTypes.array.isRequired
}