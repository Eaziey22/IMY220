import React from "react";

export class PointInput extends React.Component{

    constructor(){
        this.state = {
            p1 : "0;0",
            p2 : "0,0"

        }

        this.p1Input = React.createRef();
        this.p2Input = React.createRef();

    }

    render(){
        return(
            <div>
                <label>Point 1</label>
                <input value={this.state.p1}></input>
                <label>Point 2</label>
                <input value={this.state.p2}></input>

                <button>calculate</button>
            </div>
        );
    }
}