//Letlhogonolo Rakgantsho u21612812
const clientSocket = io();

clientSocket.on('connect', () => {
    console.log( `I connected with ID:${clientSocket.id}`);
});

clientSocket.on('updateVotes', (votes) => {
    
    updateVotes(votes);
});

document.getElementById('poll').addEventListener('submit', (e) => {
    e.preventDefault();

    const selected = document.querySelector('input[name = "catName"]:checked');
    if(selected)
    {
        const catName = selected.value;
        //console.log(catName);
        clientSocket.emit('vote', catName);

    }else{
        console.log("no cat name selected");
    }
});

clientSocket.on("whoVoted", (username) =>{
    console.log("heyy: " +username);
    const feed = document.getElementById('feed');

    const userP = document.createElement("p");

    userP.innerHTML = `user ${username} voted`;

    userP.style = "font-size: medium";

    feed.appendChild(userP);

    //feed.appendChild(document.createElement('br'));
    

}
);

let updateVotes = function(votes){
    totalVotes = 0;
   
    votes.forEach(cat => {
        //console.log(element);

        document.querySelector(`label[for=${cat.catName}] span`).textContent = cat.votes;
        totalVotes += cat.votes;

    });

    
    //console.log(totalVotes);
    document.getElementById('total-votes').textContent = totalVotes;
}