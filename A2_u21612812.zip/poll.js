//Letlhogonolo Rakgantsho u21612812
module.exports = class Poll{

    
    constructor(votesArr){
        this._votesArr = votesArr;
    }

    vote = function(name){

        const cat = this._votesArr.find(c => c.catName === name);
        //console.log(cat);
        if(cat){
            
            cat.votes++;
        }
        
        
    }

    getVotes(){
        //console.log(this._votesArr);
        return this._votesArr;
    }


}