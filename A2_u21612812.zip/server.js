//Letlhogonolo Rakgantsho u21612812
const express = require('express');
const app = express();
const http = require('http');
const server = http.createServer(app);
const { Server } = require('socket.io');
const io = new Server(server);
const Poll = require('./poll');

app.use(express.static(__dirname ));

let votes = [
    {catName: 'pebble', votes: 0},
    {catName:'sunshine' , votes: 0},
    {catName:'miso', votes:0},
    {catName:'panko',votes: 0},
    {catName:'snowball', votes: 0}
];

const poll = new Poll(votes);

io.on('connection', (socket) => {
    console.log(`A user connected with ID:${socket.id}`);

    updatedVotes = poll.getVotes();
    socket.emit('updateVotes', updatedVotes);

    socket.on('vote' , (catName) => {
        poll.vote(catName);

        updatedVotes = poll.getVotes();
        io.emit('updateVotes', updatedVotes);
        io.emit('whoVoted', socket.id.slice(0, 5));
    });

    socket.on('disconnect', () => {
        console.log("A user disconnected");
    });

    
});

app.get('/index.js', (req, res) => {
    res.setHeader('Content-Type', 'application/javascript');
    res.sendFile(__dirname + '/index.js');
});

server.listen(3000, () => {
    console.log('Listening on http://localhost:3000');
});


